# Hysteria 2.6.5 Android 应用签名密钥备份

## 备份时间
2025年12月08日 17:47:25

## 项目信息
- 项目名称: Android-Hysteria-2-client
- 版本: 2.6.5
- 应用ID: us.leaf3stones.hy2droid

## 文件清单
1. release.jks - 签名密钥库文件
2. keystore.properties - 密钥配置文件
3. README.txt - 本说明文件

## 密钥信息
KEYSTORE_FILE=../signing/release.jks
KEYSTORE_PASSWORD=jmhx4385
KEY_ALIAS=hy2droid
KEY_PASSWORD=jmhx4385


## 使用说明

### 恢复密钥
1. 将 release.jks 复制到项目的 signing/ 目录
2. 将 keystore.properties 复制到项目根目录

### 构建签名版本
`ash
./gradlew assembleRelease
`

### 重要提醒
⚠️ 请妥善保管此备份文件！
⚠️ 不要上传到公开的地方（GitHub等）
⚠️ 如果丢失，将无法发布应用更新

## 联系信息
项目仓库: https://github.com/kohakunamori/Android-Hysteria-2-client
备份创建者: KohakuNamori
